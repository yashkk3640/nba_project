export const URL_HOME = "http://localhost:3004/home";
export const URL_EMAIL = "http://localhost:3004/subscriptions";
export const URL_TEAM = "http://localhost:3004/teams";